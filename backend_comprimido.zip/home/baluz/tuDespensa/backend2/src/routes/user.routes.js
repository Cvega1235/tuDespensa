// routes/user.routes.js
import { Router } from "express";
import { getCurrentUser } from "../controllers/user.controller.js";
import { authRequired } from "../middlewares/validateToken.js";

const router = Router();

router.get("/user/me", authRequired, getCurrentUser);

export default router;
