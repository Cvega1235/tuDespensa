export const TOKEN_SECRET = process.env.TOKEN_SECRET || 'some secret key';
